package com.pgad.Constant;

public class Api {
    public static final String FEEDBACK = "/feedback";
}