package com.pgadmission.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pgadmission.main.model.Application;
import com.pgadmission.main.model.User;

public interface ApplicationRepo extends JpaRepository<Application, Long> {
	

	List<Application> findByUser(User user);
	
	@Query(value = "select * from Application where uid = :id", nativeQuery = true)
	List<Application> findByUserId(@Param("id") Long id);
}