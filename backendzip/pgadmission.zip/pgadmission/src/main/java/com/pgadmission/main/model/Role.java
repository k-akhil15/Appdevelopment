package com.pgadmission.main.model;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role {
    ADMIN,
    STUDENT
}
