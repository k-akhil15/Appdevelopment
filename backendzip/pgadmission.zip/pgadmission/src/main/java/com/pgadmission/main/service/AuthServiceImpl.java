package com.pgadmission.main.service;


import java.util.Optional;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.pgadmission.main.dto.request.AuthenticationRequest;
import com.pgadmission.main.dto.request.RegisterRequest;
import com.pgadmission.main.dto.response.AuthenticationResponse;
import com.pgadmission.main.jwtutil.JwtUtil;
import com.pgadmission.main.model.Role;
import com.pgadmission.main.model.User;
import com.pgadmission.main.repository.UserRepo;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepo userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    @Override
    public boolean userRegistration(RegisterRequest request) {
        Optional<User> isUserExists = userRepository.findByEmail(request.getEmail());
        if (!isUserExists.isPresent()) {
            var user = User.builder()
                    .name(request.getName())
                    .email(request.getEmail())
                    .password(passwordEncoder.encode(request.getPassword()))
                    .role(Role.valueOf(request.getRole().toUpperCase()))
                    .build();
            userRepository.save(user);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public AuthenticationResponse userAuthentication(AuthenticationRequest request) {
        
    	try {
    		
    	authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
        var user = userRepository.findByEmail(request.getEmail()).orElseThrow();
        var token = jwtUtil.generateToken(user);
        
        
        return AuthenticationResponse.builder()
                .token(token)
                .uid(user.getUid())
                .build();
    	}
    	catch(Exception e) {
    		
    		return AuthenticationResponse.builder()
                    .token(null)
                    .uid(null)
                    .build();
    	}
    }
}
